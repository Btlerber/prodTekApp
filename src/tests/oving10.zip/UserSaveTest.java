package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

import app.ProdTekAppController;
import app.Progress;
import app.SaveAnswer;


class UserSaveTest extends junit.framework.TestCase{
	String urlPath = "/Users/Bjorn/Documents/objOri2020/git/tdt4100-v2020-students/prodTekExport/src/tests/saveTextTest";
	Path path = Paths.get(urlPath);
	ProdTekAppController ptac = new ProdTekAppController();
	

	@Test
	void testPath(){
		ptac.setspmPath(urlPath);
		assertEquals(urlPath,ptac.getSpmPath());
	}
	
	@Test
	void checkUserAnswer(){
		//skal ikke lagres, da svaret er for kort 
		String linje0 ="11.0;;;;;;;;Forklar kort stegvis hvordan prosessen ved pulverlakkering foregår. Nevn noen fordeler ved bruk av pulverlakkering.;;;;Pulverlakkering er en 4 stegs prosess: #forbehandling, påføring av #pulver, #smelting og #kvalitetskontroll. Forbehandling: Det er avgjørende for resultatet at forbehandling er skikkelig utført, hensikten med forbehandlingen er å fjerne overflaterester og ujevnheter. Det finnes flere forskjellige forbehandlingsmetoder: Sandblåsing, syrebad eller ultrasonisk rensning m.m Forbehandling er avgjørende for levetiden til overflaten, det finnes derfor korrosjonsklasser hvor de forskjellige forbehandlingsmetodene inngår. Påføring av pulver: Etter forbehandling, begynner selve påføringen av pulver. Selve pulveret blir ladet elektrostatisk ved hjelp av sprøyte pistolen mot objektet som er jordet, pulveret fester seg til objektet på grunn av at spenningsforskjellen suger til seg til seg pulverlakken, spenning er lik over hele objekt flaten, det gjør at pulveret fordeles likt. Smelting/herding: Etter at pulveret er påført flaten til objektet, blir den ført inn i en ovn i 10 til 15 minutter på 200 grader for først å smelte sammen pulverpartikler til et sammenhengende og beskyttende lakksjikt og så for å herde den. Kvalitetskontroll: Etter at herdeprosessen er ferdig, vil det bli foretatt en visuell kontroll og deretter vil man kontrollere at filmtykkelsen er i henhold til spesifikasjonene og at den overflaten har den ønskelige glansen. Noen av fordelene med pulverlakkering er blant annet, at overflater som er pulverlakkert er robuste mot slag, støtt og riper, som kommer av det tykke lakksjikte. Overflaten tåler også godt vær og vind. Alt i alt så er pulverlakkering gode egenskaper på de fleste områder. Påføring er noe enklere vet at man kan påføre tykkere lag med lakk uten at det renner eller drypper. Pulverlakkering er en relativt billig prosess, blant annet så kan pulveret som ikke treffer flaten brukes om igjen. Dette gjør at prosessen blir mer miljøvennlig og bærekraftig enn flytende lakk.;;;;;;;;;;;;;;;;;;;;;;;;forbehandling, smelting;;;;";
		String linje1 ="21.0;;;;;;;;Hva skiller klipping fra stansing?;;;;Klipping er bearbeiding og utføres med to #egger mot hverandre. Materialet utsettes for store deformasjon og #skjærspenning rundt eggene, så det oppstår brudd. Dersom #klippekontur er sluttet, kaller vi det for #stansing.;;;;;;;;;;;;;;;;;;;;;;;;;;;;eldre_brukersvar: da utfører vi noe....";
		SaveAnswer sat0 = new SaveAnswer(linje0,"svar",path);
		SaveAnswer sat1 = new SaveAnswer(linje1,"langtsvar, lang nok til å lagres",path);
		//opretter instans og sjekker om et av svarene over er lagret.
		ptac.setspmPath(urlPath);
		ptac.currentLine = -1;
		ptac.getNextQA();
		assertEquals(linje0 , ptac.getCatalogLine());
		ptac.getNextQA();
		assertEquals(linje1 , ptac.getCatalogLine()+"eldre_brukersvar: lang nok til å lagres");
		
	}
	// kan hende metoden over må kjøre først
	@Test
	void testProgress(){
		Progress p = new Progress();
		assertEquals(0.5,p.checkProgress(urlPath));
	}
	
	@Test
	void testLength() {
		ptac.setCatalogLength(urlPath);
		assertEquals(2,ptac.getCatalogLength());
	}
	
	
}
